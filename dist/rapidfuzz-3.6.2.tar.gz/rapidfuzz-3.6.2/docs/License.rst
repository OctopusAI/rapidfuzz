.. _my-license-label:

License
=======

RapidFuzz is free and open-source software licensed under the MIT license.

MIT License
-----------

.. literalinclude:: ../LICENSE
