Longest Common Subsequence
--------------------------

Functions
^^^^^^^^^

distance
~~~~~~~~
.. autofunction:: rapidfuzz.distance.LCSseq.distance

normalized_distance
~~~~~~~~~~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.LCSseq.normalized_distance

similarity
~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.LCSseq.similarity

normalized_similarity
~~~~~~~~~~~~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.LCSseq.normalized_similarity

editops
~~~~~~~
.. autofunction:: rapidfuzz.distance.LCSseq.editops

opcodes
~~~~~~~
.. autofunction:: rapidfuzz.distance.LCSseq.opcodes
