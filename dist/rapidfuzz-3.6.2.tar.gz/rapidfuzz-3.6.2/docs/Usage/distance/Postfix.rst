Postfix
-------

Functions
^^^^^^^^^

distance
~~~~~~~~
.. autofunction:: rapidfuzz.distance.Postfix.distance

normalized_distance
~~~~~~~~~~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.Postfix.normalized_distance

similarity
~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.Postfix.similarity

normalized_similarity
~~~~~~~~~~~~~~~~~~~~~
.. autofunction:: rapidfuzz.distance.Postfix.normalized_similarity
